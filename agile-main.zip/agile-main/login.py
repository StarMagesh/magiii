name="admin"
password="1234"
name1=input("Enter your name:")
password1=input("Enter your password:")
if name1==name and password1==password:
    print("Login successful")
else:
    print("Login failed")